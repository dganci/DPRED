# DPRED/__init__.py
from .main import DPRED, PDBobj